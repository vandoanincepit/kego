<?php
/**
 * The template for displaying Archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Fruitful theme
 * @since Fruitful theme 1.0
 */

get_header(); ?>
	
	<?php fruitful_get_content_with_custom_sidebar('blogright'); ?>
	
<?php 
	get_footer(); 
?>